#include "tools.h"
#include <iostream>

using Eigen::VectorXd;
using Eigen::MatrixXd;
using std::vector;

Tools::Tools() {}

Tools::~Tools() {}

VectorXd Tools::CalculateRMSE(const vector<VectorXd> &estimations,
                              const vector<VectorXd> &ground_truth) {
  /**
   * TODO: Calculate the RMSE here.
   */
  VectorXd rmse(4);
  rmse << 0,0,0,0;
  
  unsigned int n = estimations.size();

  //Empty vector situations  
  if(estimations.size() == 0){
     cout << "ERROR --> CalculateRMSE -->  Estimations vector is empty" << endl;
     return rmse;
   }

  if(ground_truth.size() == 0){
     cout << "ERROR -->  CalculateRMSE -->  Ground-truth vector is empty" << endl;
     return rmse;
  }
  
  //Check estimate equals ground truth vector size
  if(n != ground_truth.size()){
    cout << "ERROR --> CalculateRMSE --> Estimations and ground truth vectors must be same size." << endl;
    return rmse;
  }
  
  //Calculate RMSE value
  for(unsigned int i=0; i < estimations.size(); ++i){
    VectorXd diff = estimations[i] - ground_truth[i];
    diff = diff.array()*diff.array();
    rmse += diff;
  }
  rmse = rmse / n; //get average
  rmse = rmse.array().sqrt(); //square root value
  return rmse;
}

MatrixXd Tools::CalculateJacobian(const VectorXd& x_state) {
  /**
   * TODO: Calculate a Jacobian here.
   */
  //initialize Jac matrix
  MatrixXd Hj(3,4); 
  
  //Check for errors
  if ( x_state.size() != 4 ) {
    cout << "ERROR --> CalculateJacobian --> State vector size must be 4." << endl;
    return Hj;
  }
  
  //Define state parameters
  double px = x_state(0);
  double py = x_state(1);
  double vx = x_state(2);
  double vy = x_state(3);
  
  //Define commonly used terms to avoid repetition
  double c1 = px*px+py*py;
  double c2 = sqrt(c1);
  double c3 = (c1*c2);
  
  //check division by zero
  if(fabs(c1) < 0.0001){
    cout << "ERROR --> CalculateJacobian --> Dividing by Zero" << endl;
	return Hj;
  }
  
  //compute the Jacobian matrix
  Hj << (px/c2), (py/c2), 0, 0,
		 -(py/c1), (px/c1), 0, 0,
		 py*(vx*py - vy*px)/c3, px*(px*vy - py*vx)/c3, px/c2, py/c2;
  
  return Hj;
}
